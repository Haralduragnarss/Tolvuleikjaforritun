using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Drown : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision collision) // Ef a� leikma�ur klessir
    {
        if (collision.collider.tag == "Player") // Ef a� leikma�urinn klessir objecti� sem er � vatninu
        {
            SceneManager.LoadScene(3); // Kalla� er � gameOver senuna

        }

    }
}
