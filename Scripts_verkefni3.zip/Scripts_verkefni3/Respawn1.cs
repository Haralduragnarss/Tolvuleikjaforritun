﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class Respawn : MonoBehaviour
{
	public Button yourButton; // Breyta fyrir takka skilgreind 

	void Start()
	{
		Cursor.visible = true; // Til að cursor sé sjánlegur
		Cursor.lockState = CursorLockMode.None;
		Button btn = yourButton.GetComponent<Button>(); // Til að takki geti sótt data
		btn.onClick.AddListener(Endurraesa); // Hlustar eftir virkni
	}

	public void Endurraesa()
	{
		SceneManager.LoadScene(1); //Byrjunar leikinn aftur
	}
}