using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class PlayerController : MonoBehaviour
{
    private int minY = -2; // Breyta fyrir falli�
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.y < minY) // Ef a� leilkma�urinn dettur af bor�inu ne�ar enn -3 �� respawnast hann fr� byrjun
        {
            SceneManager.LoadScene(3); // Kalla� er � gameOver senuna
        }
    }
}
