﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;


public class Bullet : MonoBehaviour
{
    public float speed=20f; // Hraði settur
    public Rigidbody rb;
    public int damage = 1; 
    public GameObject sprengjan; // GameObject fyrir sprengjuna
    public static int count;// Teljari
    private TextMeshProUGUI countText; // Texti
    void Start()
    {
        rb.velocity = transform.forward * speed; // Hraði reiknaður
        countText = GameObject.Find("Text").GetComponent<TextMeshProUGUI>();

    }
    private void OnCollisionEnter(Collision collision) // á hvað er kúlan að lenda á
    {
        
        if (collision.collider.tag=="RauðurKassi") // Ef að kúlan hittir hlut með taggið rauðurkassi
        {
            count += 10; // Leikmaður fær 10 stig
            Destroy(collision.gameObject);// eyðir hlutinum
            //Destroy(gameObject);//eyða kúlunni þarf ekki eyðist eftir 0.5 sek                 
            Sprengja(); //framkvæmir sprengju
            countText.text = "stig " + count.ToString();
        }
        if (collision.collider.tag == "enemy") // Ef að kúlan hittir hlut með taggið enemy
        {
            count += 10; // Leikmaður fær 10 stig
            Destroy(collision.gameObject); //eyðir óvin
            //Destroy(gameObject);//eyða kúlunni þarf ekki eyðist eftir 0.5 sek                 
            Sprengja(); //framkvæmir sprengju
            countText.text = "stig " + count.ToString();
        }
        if (collision.collider.tag == "goldenCoin") // Ef að kúlan hittir hlut með taggið goldenCoin
        {
            count += 50; // Leikmaður fær 50 stig
            Destroy(collision.gameObject); // eyðir kassanum
            //Destroy(gameObject);//eyða kúlunni þarf ekki eyðist eftir 0.5 sek                 
            Sprengja(); // framkvæmir sprengju
            countText.text = "stig " + count.ToString();
        }
        if (count >= 100) // Ef að leikmaðurinn fær 100 stig vinnur hann
        {
            SceneManager.LoadScene(2); // Kallað er á victory senuna
        }

    }
    
   void Sprengja() // Fallið sprengja búið til
    {
       Instantiate(sprengjan, transform.position, transform.rotation); // Sprengjan á að springa þar sem kúlan lendir
    }

}
