﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public GameObject bullet; // Hluturinn bullet búinn til
    public float speed = 100f; // Hraði kúlunar er settur
    AudioSource m_shootingSound; // Byssuhljóðs breytan

    private void Start()
    {
        m_shootingSound = GetComponent<AudioSource>(); // Kallað á hljóð breytuna
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) // EF að notandinn ýtir á space bar
        {
            Debug.Log("skjOtttttttt"); // Log

            //GameObject instBullet = Instantiate(bullet, transform.position, Quaternion.identity) as GameObject;
            GameObject instBullet = Instantiate(bullet, transform.position, transform.rotation) as GameObject; // Kúla búin til
            Rigidbody instBulletRigidbody = instBullet.GetComponent<Rigidbody>();
            instBulletRigidbody.AddForce(transform.forward * speed); // Kraftur kúlunar
            Destroy(instBullet, 0.5f);// kúlu eytt eftir 0.5sek


        }
        if (Input.GetKeyDown(KeyCode.Space)) // Ef að notandinn ýtir á space bar
        {
            m_shootingSound.Play(); // hljóðið spilar

        }

    }
}
