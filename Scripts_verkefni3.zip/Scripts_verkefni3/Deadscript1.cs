﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;


public class Deadscript : MonoBehaviour
{
	public Button yourButton; // Breyta fyrir takkann búin til

	void Start()
	{
		Button btn = yourButton.GetComponent<Button>(); // Ef að ýtt er á takkann
		btn.onClick.AddListener(Endurraesa); // Hlustar fyrir notkun
	}

	public void Endurraesa() // Fall til að byrja senur
	{
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);//næsta sena
	}
}
