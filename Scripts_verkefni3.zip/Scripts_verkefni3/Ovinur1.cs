﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class Ovinur : MonoBehaviour
{
    public static int health = 3; // Breyta fyrir líf leikmanns
    public Transform player; // Player skilgreindur
    private TextMeshProUGUI texti; // Breyta fyrir texta
    private Rigidbody rb;
    private Vector3 movement;
    public float hradi = 5f; // Hraði skilgreindur
    void Start()
    {
        texti= GameObject.Find("Text2").GetComponent<TextMeshProUGUI>(); // Fyrir textann 
        rb = this.GetComponent<Rigidbody>();
        texti.text = "Líf " + health.ToString(); // Textinn sem birtist
    }
    // Update is called once per frame
    void Update()
    {
        Vector3 stefna = player.position - transform.position; // Update-ar staðsetningu leikmans
        stefna.Normalize();
        movement = stefna; // breytan movement fær nýja staðsetningu
    }
    private void FixedUpdate()
    {
        Hreyfing(movement); // Fallið hreyfing tekur inn movement
    }
    void Hreyfing(Vector3 stefna)
    {
        rb.MovePosition(transform.position + (stefna * hradi * Time.deltaTime)); // Til að leikmaður færi sig 
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag=="Player") // Ef að óvinur hittir leikmann
        {
            Debug.Log("Leikmaður fær í sig óvin"); // Texti log
            TakeDamage(1); // Eitt líf tekið af leikmanni
            gameObject.SetActive(false);
        }
    }
    public void TakeDamage(int damage)
    {
        Debug.Log("health er núna" + (health).ToString());
        health -= damage; // Health mínuað með skaðanum sem leikmaður tók
        texti.text = "Líf " + health.ToString();
        if (health <= 0) // Ef að lekmaðurinn á engin líf eftir
        {
            SceneManager.LoadScene(3); // Scene 3 loadast
            health = 30; // Health er endursett
            Bullet.count = 0;// núll stilli stigin 
            texti.text = "Líf " + health.ToString();
        }

    }
    

}
