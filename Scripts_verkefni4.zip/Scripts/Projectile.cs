using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Projectile : MonoBehaviour
{
    
    Rigidbody2D rigidbody2d;

    void Awake() // Fall sem er alltaf a� vaka...
    {

        rigidbody2d = GetComponent<Rigidbody2D>();
    }

    public void Launch(Vector2 direction, float force) // til a� skj�ta hlutunm
    {
        rigidbody2d.AddForce(direction * force);
    }

    void Update()
    {
        if (transform.position.magnitude > 1000.0f) // Ef a� hlutinum sem er skoti� fer n�gu langt
        {
            Destroy(gameObject); // honum er eytt
        }

    }

    void OnCollisionEnter2D(Collision2D other) // Til a� sj� hvort a� �vinur skellist saman vi� �v� sem ruby skaut
    {
        enemyController e = other.collider.GetComponent<enemyController>();
        if (e != null)
        {
            e.Fix(); // Kalla� � falli� sem a� lagar r�botana
            rubyController controller = GameObject.Find("ruby").GetComponent<rubyController>(); // TIl a� n�lgast stigafj�lda Ruby �r hennar skriftu

            controller.ChangePoints(1); // eitt stig 
            if (controller.count >= 2) // Ef a� h�n n�r 2 stigum vinnur h�n
            {
                // fer � sigursenu
                SceneManager.LoadScene(3);
            }

        }

        Destroy(gameObject); // Hlutnum er svo eytt

    }
}
