using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class damageZone : MonoBehaviour
{
    void OnTriggerStay2D(Collider2D other) // ef a� ruby fer � damagezone-i�
    {
        rubyController controller = other.GetComponent<rubyController>(); // Controller ruby s�ttur

        if (controller != null)
        {
            controller.ChangeHealth(-1); // R�by missir eitt l�f 
        }
    }

}
