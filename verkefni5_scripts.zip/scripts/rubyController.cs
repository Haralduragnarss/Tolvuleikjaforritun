using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class rubyController : MonoBehaviour
{
    public TextMeshProUGUI countText; // Breyta fyrir textann 

    public float speed = 3.0f;
    public GameObject projectilePrefab;

    static public int points = 1;
    int currentPoints;

    public float timeInvincible = 1.0f;
    bool isInvincible;
    float invincibleTimer;

    Rigidbody2D rigidbody2d;
    float horizontal;
    float vertical;

    Animator animator;
    Vector2 lookDirection = new Vector2(1, 0);

    AudioSource audioSource;
    public AudioClip cogClip;

    bool isGrounded;
    public float jumpForce = 7.0f;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody2d = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();

        audioSource = GetComponent<AudioSource>();
        countText = GameObject.Find("Text").GetComponent<TextMeshProUGUI>();
        points = 1;
        countText.text = "stig " + points.ToString();



    }
    // Update is called once per frame
    void Update()
    {
        // les inn input
        horizontal = Input.GetAxis("Horizontal");
        //vertical = Input.GetAxis("Vertical");

        // Reiknar hreyfingu og sj�narhorn leikmanns
        Vector2 move = new Vector2(horizontal, 0);
        if (!Mathf.Approximately(move.x, 0.0f) || !Mathf.Approximately(move.y, 0.0f))
        {
            lookDirection.Set(move.x, move.y);
            lookDirection.Normalize();
        }

        // Velur animation eftir hra�a og sj�narhorni
        animator.SetFloat("Look X", lookDirection.x);
        animator.SetFloat("Look Y", lookDirection.y);
        animator.SetFloat("Speed", move.magnitude);

        // ef leikma�ur er �s�nilegur
        if (isInvincible)
        {
            invincibleTimer -= Time.deltaTime;
            if (invincibleTimer < 0)
                isInvincible = false;
        }

        // sk�tur ef �r�st � C
        if (Input.GetKeyDown(KeyCode.C))
        {
            Launch();
        }

        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            Debug.Log("Stekkur");
            Jump();
        }

        // x til a� spjalla
        if (Input.GetKeyDown(KeyCode.X))
        {
            // Raycast nota� til a� hefja samtal
            RaycastHit2D hit = Physics2D.Raycast(rigidbody2d.position + Vector2.up * 0.2f, lookDirection, 1.5f, LayerMask.GetMask("NPC"));
            if (hit.collider != null)
            {
                NonPlayerCharacter character = hit.collider.GetComponent<NonPlayerCharacter>();
                if (character != null)
                {
                    // s�nir talgluggann
                    character.DisplayDialog();
                }
            }
        }
    }

    void FixedUpdate()
    {
        // reiknar sta�setningu
        Vector2 position = rigidbody2d.position;
        position.x = position.x + speed * horizontal * Time.deltaTime;
        //position.y = position.y + speed * vertical * Time.deltaTime;

        // f�rir leikmann
        rigidbody2d.MovePosition(position);
    }

    // Breytir l�fum leikmanns
    public void ChangePoints(int amount)
    {
        // ef f�ribreyta er neikv��
        if (amount < 0)
        {
            if (isInvincible)
                return;

            isInvincible = true;
            invincibleTimer = timeInvincible;
        }
        points += amount;
        countText.text = "stig " + points.ToString();
    }

    void Launch()
    {
        // sk�tur g�runum
        GameObject projectileObject = Instantiate(projectilePrefab, rigidbody2d.position + Vector2.up * 0.5f, Quaternion.identity);
        Projectile projectile = projectileObject.GetComponent<Projectile>();
        projectile.Launch(lookDirection, 300);
        // spilar hlj��
        PlaySound(cogClip);
        animator.SetTrigger("Launch");
    }

    // spilar vali� hlj��
    public void PlaySound(AudioClip clip)
    {
        audioSource.PlayOneShot(clip);
    }

    // h�kkar stig
    public void AddPoints(int value)
    {
        points += value;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }

    void Jump()
    {
        transform.position += transform.up * jumpForce;
        isGrounded = false;

    }
}