using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class enemyController : MonoBehaviour
{
    public float speed; // Hra�i �vins
    public bool vertical; // Ef hann � a� fara upp og ni�ur
    public float changeTime = 3.0f;
    public ParticleSystem smokeEffect; // Fyrir reikinn
    Rigidbody2D rigidbody2D;
    float timer; // teljari
    int direction = 1; // �tt
    bool broken = true; // �eir eru skemmdir � byrjun

    Animator animator;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody2D = GetComponent<Rigidbody2D>();
        timer = changeTime;
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        //remember ! inverse the test, so if broken is true !broken will be false and return won�t be executed.
        if (!broken)
        {
            return;
        }

        timer -= Time.deltaTime;

        if (timer < 0)
        {
            direction = -direction;
            timer = changeTime;
        }
    }

    void FixedUpdate()
    {
        //remember ! inverse the test, so if broken is true !broken will be false and return won�t be executed.
        if (!broken)
        {
            return;
        }

        Vector2 position = rigidbody2D.position;

        if (vertical) // hreyfingar r�bots upp og ni�ur
        {
            position.y = position.y + Time.deltaTime * speed * direction;
            animator.SetFloat("Move X", 0);
            animator.SetFloat("Move Y", direction);
        }
        else // annars eru hreyfingar til hli�ar
        {
            position.x = position.x + Time.deltaTime * speed * direction;
            animator.SetFloat("Move X", direction);
            animator.SetFloat("Move Y", 0);
        }

        rigidbody2D.MovePosition(position);
    }

    void OnCollisionEnter2D(Collision2D other) // Ef a� Ruby lendir � �vin
    {
        rubyController player = other.gameObject.GetComponent<rubyController>();

        if (player != null)
        {
            player.ChangePoints(-1); // Ruby missir l�f 
            Debug.Log("missir stig!");
            if(rubyController.points <= 0)
            {
                SceneManager.LoadScene(2);

            }
        }
    }

}