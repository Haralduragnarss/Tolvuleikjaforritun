using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class diamondCollectible : MonoBehaviour
{
    public AudioClip collectedClip; // Fyrir hlj��i�

    void OnTriggerEnter2D(Collider2D other) // ef a� ruby skellur � collectible
    {
        Debug.Log("Kominn");
        rubyController controller = other.GetComponent<rubyController>(); // s�kir controllerinn hj� Ruby

        if (controller != null)
        {
            if (rubyController.points < 20) // Ef a� health er minna enn maxhealth
            {
                controller.ChangePoints(1); // F�r auka l�f
                Destroy(gameObject); // Jar�aberinu er eytt
                controller.PlaySound(collectedClip); // hlj�� spila�

            }
        }

    }
}
